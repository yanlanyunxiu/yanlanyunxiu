namespace GatherBuddy.Enums
{
    public enum HookSet : byte
    {
        None     = 0,
        Precise  = 1,
        Powerful = 2,
        Unknown  = 3,
    }
}
