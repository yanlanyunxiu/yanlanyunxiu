namespace GatherBuddy.Enums
{
    public enum NodeType
    {
        Regular   = 0,
        Unspoiled = 1,
        Ephemeral = 2,
    };
}
