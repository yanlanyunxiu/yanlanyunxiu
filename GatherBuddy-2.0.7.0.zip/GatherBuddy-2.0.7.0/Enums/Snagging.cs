namespace GatherBuddy.Enums
{
    public enum Snagging : byte
    {
        Unknown  = 0,
        None     = 1,
        Required = 2,
    }
}
